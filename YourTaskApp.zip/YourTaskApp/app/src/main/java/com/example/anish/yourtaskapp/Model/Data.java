package com.example.anish.yourtaskapp.Model;

public class Data {

    private String title;
    private String note;
    private String contact;
    private String date_of_scene;
    private String desp;
    private String date;
    private String id;

    public Data(){


    }

    public Data(String title, String note,String contact,String date_of_scene, String desp, String date, String id) {
        this.title = title;
        this.note = note;
        this.contact=contact;
        this.date_of_scene=date_of_scene;
        this.desp=desp;
        this.date = date;
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

   /* public void setTitle(String title) {
        this.title = title;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }*/

    /*public void setTitle(String title) {
        this.title = title;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDate_of_scene() {
        return date_of_scene;
    }

    public void setDate_of_scene(String date_of_scene) {
        this.date_of_scene = date_of_scene;
    }

    public String getDesp() {
        return desp;
    }

    public void setDesp(String desp) {
        this.desp = desp;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }*/

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getDate_of_scene() {
        return date_of_scene;
    }

    public void setDate_of_scene(String date_of_scene) {
        this.date_of_scene = date_of_scene;
    }

    public String getDesp() {
        return desp;
    }

    public void setDesp(String desp) {
        this.desp = desp;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
