package com.example.anish.yourtaskapp;

import android.annotation.TargetApi;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.anish.yourtaskapp.Model.Data;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import org.w3c.dom.Text;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.util.Date;

public class FileActivity extends AppCompatActivity {

    private android.support.v7.widget.Toolbar toolbar;

    private LinearLayout niche;
    private RelativeLayout lay1;
    private RelativeLayout lay2;
    private RelativeLayout lay3;
    private RelativeLayout lay4;
    private RelativeLayout lay5;
    private Button lay6;
    private ScrollView llPdf;
    private Bitmap bitmap;
    private FloatingActionButton fabBtn;

    private DatabaseReference mDatabase;
    private FirebaseAuth mAuth;

    //recycler view ka code

    private RecyclerView recyclerView;

    //Update variables
    private EditText titleUp;
    private EditText noteUp;
    private EditText contactUp;
    private EditText date_ofUp;
    private EditText despUp;

    private Button btnDeleteUp;
    private Button btnUpadteUp;

    private String title;
    private String note;
    private String contact;
    private String date_of_scene;
    private String desp;
    private String post_key;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);

        toolbar=findViewById(R.id.toolbar_file);

        niche=findViewById(R.id.iconsdown);
        lay1=findViewById(R.id.home1);
        lay2=findViewById(R.id.file1);
        lay3=findViewById(R.id.contact1);
        lay4=findViewById(R.id.chat1);
        lay5=findViewById(R.id.stats1);
        fabBtn=findViewById(R.id.fab_btn);


        mAuth=FirebaseAuth.getInstance();

        FirebaseUser mUser= mAuth.getCurrentUser();
        String uId= mUser.getUid();

        mDatabase=FirebaseDatabase.getInstance().getReference().child("TaskNote").child(uId);

        mDatabase.keepSynced(true);

        //recycler ka code  //////////////////////

        recyclerView=findViewById(R.id.recycler);
        LinearLayoutManager layoutManager= new LinearLayoutManager(this);

        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);

        ///////////////////

        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("File Report");


        // niche ka code //////////////////////

/*
        lay1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), HomeActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), HomeActivity.class));
            }
        });
        lay2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), FileActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), FileActivity.class));
            }
        });
        lay3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), ContactActivity.class));
            }
        });
        lay4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), Chat2Activity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), ChatActivity.class));
            }
        });
        lay5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), StatsActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                //startActivity(new Intent(getApplicationContext(), StatsActivity.class));
            }
        });

*/
        //////////////////////////

        fabBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder myDialog= new AlertDialog.Builder(FileActivity.this);

                LayoutInflater inflater= LayoutInflater.from(FileActivity.this);

                final View myview= inflater.inflate(R.layout.custominputfield,null);

                myDialog.setView(myview);

                final AlertDialog dialog=myDialog.create();

                final EditText title= myview.findViewById(R.id.edt_title);
                final EditText note=myview.findViewById(R.id.edt_note);
                final EditText contact=myview.findViewById(R.id.edt_phone);
                final EditText date_of_scene=myview.findViewById(R.id.edt_date);
                final EditText desp= myview.findViewById(R.id.edt_desp);

                Button btnSave= myview.findViewById(R.id.btn_save);

                btnSave.setOnClickListener(new View.OnClickListener() {
                    @TargetApi(Build.VERSION_CODES.KITKAT)
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
                    @Override
                    public void onClick(View v) {
                        llPdf = myview.findViewById(R.id.e11pdf);
                        Log.d("size", " " + llPdf.getWidth() + "  " + llPdf.getWidth());
                        bitmap = loadBitmapFromView(llPdf, llPdf.getWidth(), llPdf.getHeight());
                        createPdf();
                        String mTitle=title.getText().toString().trim();
                                String mNote=note.getText().toString().trim();
                                String mContact=contact.getText().toString().trim();
                                String mDate=date_of_scene.getText().toString().trim();
                                String mDesp=desp.getText().toString().trim();

                                if(TextUtils.isEmpty(mTitle))
                                {
                                    title.setError("Required Field..");
                                    return;
                                }

                                if(TextUtils.isEmpty(mContact)){
                                    note.setError("Required Field..");
                                    return;
                                }
                        if(TextUtils.isEmpty(mDate)){
                            note.setError("Required Field..");
                            return;
                        }
                        if(TextUtils.isEmpty(mContact)){
                            note.setError("Required Field..");
                            return;
                        }
                        if(TextUtils.isEmpty(mDesp)){
                            note.setError("Required Field..");
                            return;
                        }




                        String id=mDatabase.push().getKey();

                                String datee= DateFormat.getDateInstance().format(new Date());

                                Data data = new Data(mTitle,mNote,mContact,mDate,mDesp,datee,id);

                                mDatabase.child(id).setValue(data);

                        Toast.makeText(getApplicationContext(), "Data Inserted", Toast.LENGTH_SHORT).show();

                        dialog.dismiss();

                    }
                });

                dialog.show();



            }
        });


    }
    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Data, MyViewHolder> adapter= new FirebaseRecyclerAdapter<Data, MyViewHolder>(
                Data.class,
                R.layout.item_data,
                MyViewHolder.class,
                mDatabase
        ){

            @Override
            protected void populateViewHolder(MyViewHolder viewHolder, final Data model, final int position) {

                viewHolder.setTitle(model.getTitle());
                viewHolder.setNote(model.getNote());
               viewHolder.setContact(model.getContact());
               viewHolder.setDate_of_scene(model.getDate_of_scene());
               viewHolder.setDesp(model.getDesp());

                viewHolder.setDate(model.getDate());

                viewHolder.myview.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        post_key=getRef(position).getKey();
                        title=model.getTitle();
                        note=model.getNote();
                        contact=model.getContact();
                        date_of_scene=model.getDate_of_scene();
                        desp=model.getDesp();



                        updateData();
                    }
                });

            }
        };
        recyclerView.setAdapter(adapter);



    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        View myview;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            myview=itemView;
        }

        public void setTitle(String title){
            TextView mTitle=myview.findViewById(R.id.title);
            mTitle.setText(title);
        }

        public void setNote(String note){

            TextView mNote=myview.findViewById(R.id.note);
            mNote.setText(note);
        }
        public void setContact(String contact) {
           TextView mContact=myview.findViewById(R.id.number);
           mContact.setText(contact);
        }

        public void setDate_of_scene(String date_of_scene) {
           TextView mDate_of_scene=myview.findViewById(R.id.date_of);
           mDate_of_scene.setText(date_of_scene);
        }

        public void setDesp(String desp) {
            TextView mDesp=myview.findViewById(R.id.description);
            mDesp.setText(desp);
        }
        public void setDate(String date){
            TextView mDate=myview.findViewById(R.id.date);
            mDate.setText(date);
        }


    }

    public void updateData(){
        AlertDialog.Builder mydialdog= new AlertDialog.Builder(FileActivity.this);
        LayoutInflater inflater = LayoutInflater.from(FileActivity.this);
        View myview= inflater.inflate(R.layout.updateinputfield,null);
        mydialdog.setView(myview);

        final AlertDialog dialog = mydialdog.create();

        titleUp=myview.findViewById(R.id.edt_title_upd);
        noteUp=myview.findViewById(R.id.edt_note_upd);
        contactUp=myview.findViewById(R.id.edt_contact_upd);
        date_ofUp=myview.findViewById(R.id.edt_date_of_upd);
        despUp=myview.findViewById(R.id.edt_desp_upd);


        titleUp.setText(title);
        titleUp.setSelection(title.length());

        noteUp.setText(note);
        noteUp.setSelection(note.length());

        contactUp.setText(contact);
        contactUp.setSelection(contact.length());

        date_ofUp.setText(date_of_scene);
        date_ofUp.setSelection(date_of_scene.length());

        despUp.setText(desp);
        despUp.setSelection(desp.length());

        btnDeleteUp=myview.findViewById(R.id.btn_delete_upd);
        btnUpadteUp=myview.findViewById(R.id.btn_update_upd);

        btnUpadteUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                title=titleUp.getText().toString().trim();
                note=noteUp.getText().toString().trim();
                contact=contactUp.getText().toString().trim();
                date_of_scene=date_ofUp.getText().toString().trim();
                desp=despUp.getText().toString().trim();


                String mDate=DateFormat.getDateInstance().format(new Date());

                Data data= new Data(title,note,contact,date_of_scene,desp,mDate,post_key);

                mDatabase.child(post_key).setValue(data);

                dialog.dismiss();
            }
        });

        btnDeleteUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mDatabase.child(post_key).removeValue();

                dialog.dismiss();
            }
        });

        dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){

            case R.id.logout:
                mAuth.signOut();
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                break;


        }
        return super.onOptionsItemSelected(item);
    }
    public static Bitmap loadBitmapFromView(View v, int width, int height) {
        Bitmap b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        v.draw(c);

        return b;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void createPdf(){
        WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        //  Display display = wm.getDefaultDisplay();
        DisplayMetrics displaymetrics = new DisplayMetrics();
        this.getWindowManager().getDefaultDisplay().getMetrics(displaymetrics);
        float hight = displaymetrics.heightPixels ;
        float width = displaymetrics.widthPixels ;


        int convertHighet = (int) hight, convertWidth = (int) width;

//        Resources mResources = getResources();
//        Bitmap bitmap = BitmapFactory.decodeResource(mResources, R.drawable.screenshot);

        PdfDocument document = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(convertWidth, convertHighet, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);

        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();
        canvas.drawPaint(paint);

        bitmap = Bitmap.createScaledBitmap(bitmap, convertWidth, convertHighet, true);

        paint.setColor(Color.BLUE);
        canvas.drawBitmap(bitmap, 0, 0 , null);
        document.finishPage(page);

        // write the document content
        String targetPdf = "/sdcard/pdffromlayout23.pdf";
        File filePath;
        filePath = new File(targetPdf);
        try {
            document.writeTo(new FileOutputStream(filePath));

        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Something wrong: " + e.toString(), Toast.LENGTH_LONG).show();
        }

        // close the document
        document.close();
        Toast.makeText(this, "PDF is created!!!", Toast.LENGTH_SHORT).show();

        openGeneratedPDF();

    }

    private void openGeneratedPDF(){
        File file = new File("/sdcard/pdffromlayout23.pdf");
        if (file.exists())
        {
            Intent intent=new Intent(Intent.ACTION_VIEW);
            Uri uri = FileProvider.getUriForFile(this,BuildConfig.APPLICATION_ID +".provider" ,file);
            intent.setDataAndType(uri, "application/pdf");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);


            try
            {
                startActivity(intent);
            }
            catch(ActivityNotFoundException e)
            {
                Toast.makeText(FileActivity.this, "No Application available to view pdf", Toast.LENGTH_LONG).show();
            }
        }
    }

}// main file ends here
